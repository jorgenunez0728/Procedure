const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, LevelFormat, VerticalAlign, ImageRun, PageBreak
} = require('docx');
const fs = require('fs');

// Read procedure data from arg
const procData = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const outputPath = process.argv[3];

// ── HELPERS ──────────────────────────────────────────────────────────
const border = { style: BorderStyle.SINGLE, size: 4, color: "1A3A6B" };
const borderThin = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const allBorders = (b) => ({ top: b, bottom: b, left: b, right: b });
const cellMargins = { top: 80, bottom: 80, left: 120, right: 120 };

function heading(text, level = 1) {
  const sizes = { 1: 28, 2: 24, 3: 22 };
  return new Paragraph({
    spacing: { before: level === 1 ? 240 : 160, after: 120 },
    children: [
      new TextRun({
        text,
        bold: true,
        size: sizes[level] || 22,
        font: "Arial",
        color: level === 1 ? "1A3A6B" : "1A1A18"
      })
    ]
  });
}

function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 80 },
    alignment: opts.justify ? AlignmentType.BOTH : AlignmentType.LEFT,
    children: [
      new TextRun({
        text,
        size: 20,
        font: "Arial",
        bold: opts.bold || false,
        italics: opts.italic || false,
        color: "1A1A18"
      })
    ]
  });
}

function spacer() {
  return new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: "" })] });
}

function sectionLabel(roman, title) {
  return new Paragraph({
    spacing: { before: 280, after: 100 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "1A3A6B", space: 4 } },
    children: [
      new TextRun({ text: `${roman}. `, bold: true, size: 24, font: "Arial", color: "C8380A" }),
      new TextRun({ text: title, bold: true, size: 24, font: "Arial", color: "1A3A6B" })
    ]
  });
}

function numberedList(items, ref) {
  return items.map((item, i) =>
    new Paragraph({
      numbering: { reference: ref, level: 0 },
      spacing: { after: 80 },
      children: [new TextRun({ text: item, size: 20, font: "Arial" })]
    })
  );
}

// ── HEADER ───────────────────────────────────────────────────────────
function buildHeader(d) {
  // Header: title centered, doc info on right
  const titlePara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 0 },
    children: [
      new TextRun({ text: "Laboratorio de Emisiones  |  KMX", bold: true, size: 26, font: "Arial", color: "1A3A6B" })
    ]
  });
  const subtitlePara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 0 },
    children: [
      new TextRun({ text: d.title || "Procedimiento", size: 22, font: "Arial", color: "333333" })
    ]
  });

  // Info table: doc# | revision | date | dept
  const infoTable = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2700, 1500, 2460, 2700],
    borders: allBorders(borderThin),
    rows: [
      new TableRow({
        children: [
          new TableCell({
            borders: allBorders(borderThin),
            width: { size: 2700, type: WidthType.DXA },
            margins: cellMargins,
            shading: { fill: "E8EDF5", type: ShadingType.CLEAR },
            children: [new Paragraph({ children: [
              new TextRun({ text: "Document#: ", bold: true, size: 16, font: "Arial" }),
              new TextRun({ text: d.code || "KMX-P---", size: 16, font: "Arial" })
            ]})]
          }),
          new TableCell({
            borders: allBorders(borderThin),
            width: { size: 1500, type: WidthType.DXA },
            margins: cellMargins,
            shading: { fill: "E8EDF5", type: ShadingType.CLEAR },
            children: [new Paragraph({ children: [
              new TextRun({ text: "Rev: ", bold: true, size: 16, font: "Arial" }),
              new TextRun({ text: d.revision || "1", size: 16, font: "Arial" })
            ]})]
          }),
          new TableCell({
            borders: allBorders(borderThin),
            width: { size: 2460, type: WidthType.DXA },
            margins: cellMargins,
            shading: { fill: "E8EDF5", type: ShadingType.CLEAR },
            children: [new Paragraph({ children: [
              new TextRun({ text: "Date: ", bold: true, size: 16, font: "Arial" }),
              new TextRun({ text: d.date || new Date().toLocaleDateString('es-MX'), size: 16, font: "Arial" })
            ]})]
          }),
          new TableCell({
            borders: allBorders(borderThin),
            width: { size: 2700, type: WidthType.DXA },
            margins: cellMargins,
            shading: { fill: "E8EDF5", type: ShadingType.CLEAR },
            children: [new Paragraph({ children: [
              new TextRun({ text: "Dept: ", bold: true, size: 16, font: "Arial" }),
              new TextRun({ text: "QA / Emisiones", size: 16, font: "Arial" })
            ]})]
          }),
        ]
      })
    ]
  });

  return new Header({ children: [titlePara, subtitlePara, spacer(), infoTable] });
}

// ── DEFINITIONS TABLE ─────────────────────────────────────────────
function buildDefsTable(defs) {
  if (!defs || defs.length === 0) return [];
  const headerRow = new TableRow({
    tableHeader: true,
    children: [
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: 3120, type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: "1A3A6B", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: "Término / Element", bold: true, size: 18, font: "Arial", color: "FFFFFF" })] })]
      }),
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: 6240, type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: "1A3A6B", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: "Definición / Definition", bold: true, size: 18, font: "Arial", color: "FFFFFF" })] })]
      }),
    ]
  });

  const dataRows = defs.map((d, i) => new TableRow({
    children: [
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: 3120, type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: i % 2 === 0 ? "FFFFFF" : "F4F3EF", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: d.term || "", bold: true, size: 18, font: "Arial" })] })]
      }),
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: 6240, type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: i % 2 === 0 ? "FFFFFF" : "F4F3EF", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: d.definition || "", size: 18, font: "Arial" })] })]
      }),
    ]
  }));

  return [new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [3120, 6240], borders: allBorders(borderThin), rows: [headerRow, ...dataRows] })];
}

// ── RESPONSIBILITIES TABLE ────────────────────────────────────────
function buildRespTable(resps) {
  if (!resps || resps.length === 0) return [];
  const colWidths = [3120, 3120, 3120];
  const headerRow = new TableRow({
    tableHeader: true,
    children: ["Posición / Position", "Responsabilidad", "Autoridad"].map((t, i) =>
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: colWidths[i], type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: "1A3A6B", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: t, bold: true, size: 18, font: "Arial", color: "FFFFFF" })] })]
      })
    )
  });

  const dataRows = resps.map((r, i) => new TableRow({
    children: [r.role || "", r.responsibility || "", r.authority || ""].map((t, ci) =>
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: colWidths[ci], type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: i % 2 === 0 ? "FFFFFF" : "F4F3EF", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: t, size: 18, font: "Arial", bold: ci === 0 })] })]
      })
    )
  }));

  return [new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: colWidths, borders: allBorders(borderThin), rows: [headerRow, ...dataRows] })];
}

// ── CHANGE LOG TABLE ─────────────────────────────────────────────
function buildChangeLog(d) {
  const colWidths = [936, 1872, 1872, 1872, 2808];
  const headerRow = new TableRow({
    tableHeader: true,
    children: ["Rev.", "Fecha", "Elaboró", "Sección", "Descripción del Cambio"].map((t, i) =>
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: colWidths[i], type: WidthType.DXA },
        margins: cellMargins,
        shading: { fill: "1A3A6B", type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: t, bold: true, size: 16, font: "Arial", color: "FFFFFF" })] })]
      })
    )
  });

  const dataRow = new TableRow({
    children: [
      d.revision || "1",
      d.date || new Date().toLocaleDateString('es-MX'),
      d.author || "",
      "Documento completo",
      "Creación del documento"
    ].map((t, i) =>
      new TableCell({
        borders: allBorders(borderThin),
        width: { size: colWidths[i], type: WidthType.DXA },
        margins: cellMargins,
        children: [new Paragraph({ children: [new TextRun({ text: t, size: 16, font: "Arial" })] })]
      })
    )
  });

  return [new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: colWidths, borders: allBorders(borderThin), rows: [headerRow, dataRow] })];
}

// ── BUILD DOCUMENT ────────────────────────────────────────────────
async function build(d) {
  const children = [];

  // Title page block
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 240 },
      children: [new TextRun({ text: d.title || "Procedimiento Técnico", bold: true, size: 48, font: "Arial", color: "1A3A6B" })]
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 480 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: "C8380A" } },
      children: [new TextRun({ text: `${d.code || ""}  ·  Rev. ${d.revision || "1"}  ·  ${d.date || ""}`, size: 22, font: "Arial", color: "555555" })]
    }),
    spacer(),
  );

  // I. PURPOSE
  children.push(sectionLabel("I", "Propósito / Purpose"), spacer());
  if (d.purpose) children.push(body(d.purpose, { justify: true }));
  children.push(spacer());

  // II. SCOPE
  children.push(sectionLabel("II", "Alcance / Scope"), spacer());
  if (d.scope) children.push(body(d.scope, { justify: true }));
  children.push(spacer());

  // III. DEFINITIONS
  if (d.definitions && d.definitions.length > 0) {
    children.push(sectionLabel("III", "Definiciones / Definitions"), spacer());
    children.push(...buildDefsTable(d.definitions));
    children.push(spacer());
  }

  // IV. RESPONSIBILITIES
  if (d.responsibilities && d.responsibilities.length > 0) {
    children.push(sectionLabel("IV", "Responsabilidades / Responsibilities"), spacer());
    children.push(...buildRespTable(d.responsibilities));
    children.push(spacer());
  }

  // V. PROCEDURE
  if (d.steps && d.steps.length > 0) {
    children.push(sectionLabel("V", "Procedimiento / Procedure"), spacer());

    // General requirements if present
    if (d.general_requirements) {
      children.push(body("1. Requisitos Generales", { bold: true }));
      children.push(body(d.general_requirements, { justify: true }));
      children.push(spacer());
    }

    // Steps
    for (const step of d.steps) {
      const stepNum = step.number || (d.steps.indexOf(step) + 1);
      children.push(
        new Paragraph({
          spacing: { before: 160, after: 80 },
          children: [
            new TextRun({ text: `${stepNum}. `, bold: true, size: 22, font: "Arial", color: "C8380A" }),
            new TextRun({ text: step.title || "", bold: true, size: 22, font: "Arial", color: "1A1A18" })
          ]
        })
      );
      if (step.description) children.push(body(step.description, { justify: true }));
      if (step.notes) {
        children.push(
          new Paragraph({
            spacing: { before: 80, after: 80 },
            indent: { left: 720 },
            children: [
              new TextRun({ text: "⚠ Nota: ", bold: true, size: 18, font: "Arial", color: "C8380A" }),
              new TextRun({ text: step.notes, size: 18, font: "Arial", italics: true, color: "555555" })
            ]
          })
        );
      }

      // Image placeholder if step has image
      if (step.hasImage || step.imagePath) {
        if (step.imagePath && fs.existsSync(step.imagePath)) {
          const imgBuffer = fs.readFileSync(step.imagePath);
          children.push(
            new Paragraph({
              spacing: { before: 80, after: 80 },
              children: [new ImageRun({ data: imgBuffer, transformation: { width: 400, height: 280 }, type: "jpg" })]
            })
          );
        } else {
          // Placeholder box
          children.push(
            new Paragraph({
              spacing: { before: 80, after: 80 },
              indent: { left: 720 },
              children: [new TextRun({ text: "[ Imagen del paso — adjuntar al documento ]", size: 18, font: "Arial", color: "999999", italics: true })]
            })
          );
        }
      }
    }
    children.push(spacer());
  }

  // VI. ACCEPTANCE CRITERIA
  if (d.acceptance_criteria) {
    children.push(sectionLabel("VI", "Criterios de Aceptación"), spacer());
    children.push(body(d.acceptance_criteria, { justify: true }));
    children.push(spacer());
  }

  // VII. RECORDS
  if (d.records) {
    children.push(sectionLabel("VII", "Registros y Documentos"), spacer());
    children.push(body(d.records, { justify: true }));
    children.push(spacer());
  }

  // VIII. RELATED PROCEDURES
  if (d.related_procedures && d.related_procedures.length > 0) {
    children.push(sectionLabel("VIII", "Procedimientos Relacionados"), spacer());
    d.related_procedures.forEach(rp => children.push(body(`• ${rp}`)));
    children.push(spacer());
  }

  // IX. CHANGE LOG
  children.push(sectionLabel("IX", "Control de Cambios / Change Description"), spacer());
  children.push(...buildChangeLog(d));

  // Build doc
  const doc = new Document({
    numbering: {
      config: [
        {
          reference: "numbered",
          levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
        }
      ]
    },
    styles: {
      default: {
        document: { run: { font: "Arial", size: 20 } }
      }
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1800, right: 1200, bottom: 1200, left: 1200 }
        }
      },
      headers: { default: buildHeader(d) },
      children
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputPath, buffer);
  console.log(`OK:${outputPath}`);
}

build(procData).catch(e => { console.error("ERROR:" + e.message); process.exit(1); });
